# Weather Forecast App

Built with React. Uses OpenWeatherMap's API. Deployed via Netlify [here](https://alexkowsik-weather-app.netlify.com/).

![screenshot of the app](https://raw.githubusercontent.com/alexkowsik/react-weather-app/master/src/images/screenshot.png "New York")
